export {
    connectToWallet123
} from './web3';