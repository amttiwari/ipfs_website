export {
    disconnectToWallet
} from './web3';